$ORIGIN .
$TTL 604800	; 1 week
ovpnprivate.dw-lab.com	IN SOA	dwlab-central-01.ovpnprivate.dw-lab.com. admin.ovpnprivate.dw-lab.com. (
				492        ; serial
				604800     ; refresh (1 week)
				86400      ; retry (1 day)
				2419200    ; expire (4 weeks)
				604800     ; minimum (1 week)
				)
			NS	dwlab-central-01.ovpnprivate.dw-lab.com.
$ORIGIN ovpnprivate.dw-lab.com.
$TTL 86400	; 1 day
dw-media-wz		A	10.8.4.8
$TTL 604800	; 1 week
dwlab-central-01	A	10.8.4.1
